-- ============================================================
-- TUNEDIK — Committee Reports Migration
-- Run this after migrate_committees.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS `committee_reports` (
  `id`            INT(11)       NOT NULL AUTO_INCREMENT,
  `committee_id`  INT(11)       NOT NULL,
  `uploaded_by`   INT(11)       NOT NULL,
  `title`         VARCHAR(255)  NOT NULL,
  `filename`      VARCHAR(500)  NOT NULL,
  `original_name` VARCHAR(500)  NOT NULL,
  `uploaded_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cr_committee` (`committee_id`),
  KEY `idx_cr_uploader`  (`uploaded_by`),
  CONSTRAINT `fk_cr_committee` FOREIGN KEY (`committee_id`) REFERENCES `committees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cr_uploader`  FOREIGN KEY (`uploaded_by`)  REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
