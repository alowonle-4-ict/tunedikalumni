-- Migration: Add developer_url setting
INSERT INTO settings (setting_key, setting_value)
VALUES ('developer_url', '')
ON DUPLICATE KEY UPDATE setting_key = setting_key;
