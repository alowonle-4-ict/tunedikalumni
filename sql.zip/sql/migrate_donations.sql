-- Migration: Donation / Fundraising Campaigns
-- Run this on existing databases.

CREATE TABLE IF NOT EXISTS `donation_campaigns` (
  `id`                  INT(11)       NOT NULL AUTO_INCREMENT,
  `title`               VARCHAR(255)  NOT NULL,
  `description`         TEXT          DEFAULT NULL,
  `target_amount`       DECIMAL(12,2) NOT NULL DEFAULT 0.00  COMMENT '0 = no target / unlimited',
  `beneficiary_user_id` INT(11)       DEFAULT NULL            COMMENT 'NULL = project/cause, not a member',
  `beneficiary_name`    VARCHAR(255)  DEFAULT NULL            COMMENT 'Free-text for project or non-member',
  `slug`                VARCHAR(32)   NOT NULL,
  `deadline`            DATE          DEFAULT NULL,
  `show_donors`         TINYINT(1)    NOT NULL DEFAULT 1      COMMENT 'Show donor list publicly',
  `status`              ENUM('active','closed','draft') NOT NULL DEFAULT 'active',
  `created_by`          INT(11)       NOT NULL,
  `created_at`          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_dc_beneficiary` FOREIGN KEY (`beneficiary_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dc_creator`     FOREIGN KEY (`created_by`)          REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `donation_payments` (
  `id`           INT(11)       NOT NULL AUTO_INCREMENT,
  `campaign_id`  INT(11)       NOT NULL,
  `donor_name`   VARCHAR(255)  NOT NULL,
  `donor_email`  VARCHAR(255)  NOT NULL,
  `amount`       DECIMAL(10,2) NOT NULL,
  `reference`    VARCHAR(255)  NOT NULL,
  `method`       ENUM('paystack','manual') NOT NULL DEFAULT 'paystack',
  `status`       ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
  `message`      TEXT          DEFAULT NULL,
  `is_anonymous` TINYINT(1)    NOT NULL DEFAULT 0,
  `recorded_by`  INT(11)       DEFAULT NULL               COMMENT 'Admin who entered a manual donation',
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ref` (`reference`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_status`   (`status`),
  CONSTRAINT `fk_dp_campaign`  FOREIGN KEY (`campaign_id`) REFERENCES `donation_campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dp_recorder`  FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
