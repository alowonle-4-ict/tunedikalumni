-- Migration: Add manual clearance payment methods
-- Run this on existing databases that were set up before this feature was added.

ALTER TABLE `payments`
  MODIFY COLUMN `method`
    ENUM('paystack','offline','bank_transfer','cash','cheque','manual')
    NOT NULL;
