-- ================================================================
-- TUNEDIK — Loan Management Feature Migration
-- ================================================================

CREATE TABLE IF NOT EXISTS `loans` (
  `id`                   INT(11)         NOT NULL AUTO_INCREMENT,
  `user_id`              INT(11)         NOT NULL,
  `amount`               DECIMAL(12,2)   NOT NULL,
  `purpose`              TEXT            NOT NULL,
  `bank_name`            VARCHAR(100)    NOT NULL DEFAULT '',
  `account_number`       VARCHAR(20)     NOT NULL DEFAULT '',
  `account_name`         VARCHAR(200)    NOT NULL DEFAULT '',
  `repayment_period`     INT(11)         NOT NULL COMMENT 'in months',
  `monthly_amount`       DECIMAL(12,2)   NOT NULL COMMENT 'amount member commits per month',
  `total_repaid`         DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
  `status`               ENUM('pending_guarantors','pending_admin','approved','rejected','active','completed')
                                         NOT NULL DEFAULT 'pending_guarantors',
  `approved_by`          INT(11)         DEFAULT NULL,
  `approved_at`          TIMESTAMP       NULL DEFAULT NULL,
  `disbursed_at`         TIMESTAMP       NULL DEFAULT NULL,
  `admin_notes`          TEXT            DEFAULT NULL,
  `consecutive_missed`   INT(11)         NOT NULL DEFAULT 0,
  `last_repayment_date`  DATE            DEFAULT NULL,
  `created_at`           TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_loan_user`   (`user_id`),
  KEY `idx_loan_status` (`status`),
  CONSTRAINT `fk_loan_user`     FOREIGN KEY (`user_id`)     REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_loan_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_guarantors` (
  `id`                   INT(11)         NOT NULL AUTO_INCREMENT,
  `loan_id`              INT(11)         NOT NULL,
  `guarantor_user_id`    INT(11)         NOT NULL,
  `status`               ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  `responded_at`         TIMESTAMP       NULL DEFAULT NULL,
  `reject_reason`        TEXT            DEFAULT NULL,
  `created_at`           TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_loan_guarantor` (`loan_id`, `guarantor_user_id`),
  KEY `idx_lg_guarantor` (`guarantor_user_id`),
  CONSTRAINT `fk_lg_loan` FOREIGN KEY (`loan_id`)           REFERENCES `loans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lg_user` FOREIGN KEY (`guarantor_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `loan_repayments` (
  `id`                   INT(11)         NOT NULL AUTO_INCREMENT,
  `loan_id`              INT(11)         NOT NULL,
  `principal_amount`     DECIMAL(12,2)   NOT NULL,
  `transaction_fee`      DECIMAL(12,2)   NOT NULL DEFAULT 150.00,
  `total_paid`           DECIMAL(12,2)   NOT NULL,
  `payment_date`         DATE            NOT NULL,
  `notes`                TEXT            DEFAULT NULL,
  `method`               ENUM('paystack','offline','admin') NOT NULL DEFAULT 'admin',
  `reference`            VARCHAR(100)    DEFAULT NULL,
  `receipt_file`         VARCHAR(255)    DEFAULT NULL,
  `status`               ENUM('pending','confirmed') NOT NULL DEFAULT 'confirmed',
  `verified_by`          INT(11)         DEFAULT NULL,
  `verified_at`          TIMESTAMP       NULL DEFAULT NULL,
  `recorded_by`          INT(11)         DEFAULT NULL,
  `created_at`           TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_repay_loan`      (`loan_id`),
  KEY `idx_repay_reference` (`reference`),
  CONSTRAINT `fk_repay_loan`      FOREIGN KEY (`loan_id`)     REFERENCES `loans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_repay_verifier`  FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_repay_recorder`  FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- If loan_repayments table already exists from an earlier migration,
-- run these ALTER statements to add the missing columns:
-- ================================================================
-- ALTER TABLE `loan_repayments`
--   ADD COLUMN IF NOT EXISTS `method`       ENUM('paystack','offline','admin') NOT NULL DEFAULT 'admin' AFTER `notes`,
--   ADD COLUMN IF NOT EXISTS `reference`    VARCHAR(100)  DEFAULT NULL AFTER `method`,
--   ADD COLUMN IF NOT EXISTS `receipt_file` VARCHAR(255)  DEFAULT NULL AFTER `reference`,
--   ADD COLUMN IF NOT EXISTS `status`       ENUM('pending','confirmed') NOT NULL DEFAULT 'confirmed' AFTER `receipt_file`,
--   ADD COLUMN IF NOT EXISTS `verified_by`  INT(11)       DEFAULT NULL AFTER `status`,
--   ADD COLUMN IF NOT EXISTS `verified_at`  TIMESTAMP     NULL DEFAULT NULL AFTER `verified_by`;
