-- ============================================================
-- TUNEDIK — Forum System Migration
-- ============================================================

-- 1. Forum categories
CREATE TABLE IF NOT EXISTS `forum_categories` (
  `id`            INT(11)      NOT NULL AUTO_INCREMENT,
  `name`          VARCHAR(100) NOT NULL,
  `description`   TEXT         DEFAULT NULL,
  `slug`          VARCHAR(120) NOT NULL,
  `icon`          VARCHAR(50)  NOT NULL DEFAULT 'bi-chat-dots-fill',
  `display_order` SMALLINT(6)  NOT NULL DEFAULT 0,
  `created_by`    INT(11)      NOT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_order` (`display_order`),
  CONSTRAINT `fk_fc_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Forum topics / threads
CREATE TABLE IF NOT EXISTS `forum_topics` (
  `id`                 INT(11)      NOT NULL AUTO_INCREMENT,
  `category_id`        INT(11)      NOT NULL,
  `user_id`            INT(11)      NOT NULL,
  `title`              VARCHAR(255) NOT NULL,
  `slug`               VARCHAR(300) NOT NULL,
  `views`              INT(11)      NOT NULL DEFAULT 0,
  `is_pinned`          TINYINT(1)   NOT NULL DEFAULT 0,
  `is_locked`          TINYINT(1)   NOT NULL DEFAULT 0,
  `last_post_at`       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_post_user_id`  INT(11)      DEFAULT NULL,
  `created_at`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category`  (`category_id`),
  KEY `idx_last_post` (`last_post_at`),
  CONSTRAINT `fk_ft_category`  FOREIGN KEY (`category_id`)       REFERENCES `forum_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ft_user`      FOREIGN KEY (`user_id`)            REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ft_last_user` FOREIGN KEY (`last_post_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Forum posts (first post is the topic body; subsequent posts are replies)
CREATE TABLE IF NOT EXISTS `forum_posts` (
  `id`            INT(11)    NOT NULL AUTO_INCREMENT,
  `topic_id`      INT(11)    NOT NULL,
  `user_id`       INT(11)    NOT NULL,
  `body`          TEXT       NOT NULL,
  `quote_post_id` INT(11)    DEFAULT NULL,
  `is_deleted`    TINYINT(1) NOT NULL DEFAULT 0,
  `edited_at`     TIMESTAMP  NULL DEFAULT NULL,
  `created_at`    TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_topic` (`topic_id`),
  KEY `idx_user`  (`user_id`),
  CONSTRAINT `fk_fp_topic` FOREIGN KEY (`topic_id`)      REFERENCES `forum_topics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fp_user`  FOREIGN KEY (`user_id`)       REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fp_quote` FOREIGN KEY (`quote_post_id`) REFERENCES `forum_posts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Post likes
CREATE TABLE IF NOT EXISTS `forum_likes` (
  `id`         INT(11)   NOT NULL AUTO_INCREMENT,
  `post_id`    INT(11)   NOT NULL,
  `user_id`    INT(11)   NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_post_user` (`post_id`, `user_id`),
  KEY `idx_post` (`post_id`),
  CONSTRAINT `fk_fl_post` FOREIGN KEY (`post_id`) REFERENCES `forum_posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fl_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Seed default categories (optional — remove if unwanted)
-- INSERT INTO `forum_categories` (name, description, slug, icon, display_order, created_by)
-- SELECT 'General Discussion','Talk about anything alumni-related','general-discussion','bi-chat-dots-fill',1,id
-- FROM users WHERE role='admin' LIMIT 1;
