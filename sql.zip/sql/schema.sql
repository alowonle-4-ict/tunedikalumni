-- ============================================================
-- TUNEDIK Alumni Management System — Database Schema v1.0
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `tunexapa_tunedik`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `tunexapa_tunedik`;

-- -----------------------------------------------------------
-- settings  (key/value store for all admin-controlled config)
-- -----------------------------------------------------------
CREATE TABLE `settings` (
  `id`            INT(11)      NOT NULL AUTO_INCREMENT,
  `setting_key`   VARCHAR(100) NOT NULL,
  `setting_value` TEXT         DEFAULT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- users
-- -----------------------------------------------------------
CREATE TABLE `users` (
  `id`              INT(11)      NOT NULL AUTO_INCREMENT,
  `first_name`      VARCHAR(100) NOT NULL,
  `last_name`       VARCHAR(100) NOT NULL,
  `email`           VARCHAR(255) NOT NULL,
  `phone`           VARCHAR(20)  DEFAULT NULL,
  `password`        VARCHAR(255) NOT NULL,
  `state`           VARCHAR(100) DEFAULT NULL,
  `country`         VARCHAR(100) NOT NULL DEFAULT 'Nigeria',
  `department`      VARCHAR(200) DEFAULT NULL,
  `graduation_year` YEAR         DEFAULT NULL,
  `role`            ENUM('member','financial_secretary','admin') NOT NULL DEFAULT 'member',
  `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- membership_serials  (independent counter per location code)
-- -----------------------------------------------------------
CREATE TABLE `membership_serials` (
  `id`            INT(11)     NOT NULL AUTO_INCREMENT,
  `location_code` VARCHAR(10) NOT NULL,
  `last_serial`   INT(11)     NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_location_code` (`location_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- memberships
-- -----------------------------------------------------------
CREATE TABLE `memberships` (
  `id`                     INT(11)     NOT NULL AUTO_INCREMENT,
  `user_id`                INT(11)     NOT NULL,
  `membership_id`          VARCHAR(50) NOT NULL,
  `location_code`          VARCHAR(10) NOT NULL,
  `serial_number`          INT(11)     NOT NULL,
  `status`                 ENUM('pending','active','expired') NOT NULL DEFAULT 'pending',
  `membership_start_date`  DATE        DEFAULT NULL,
  `membership_expiry_date` DATE        DEFAULT NULL,
  `created_at`             TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`             TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_membership_id` (`membership_id`),
  UNIQUE KEY `uq_user_id` (`user_id`),
  CONSTRAINT `fk_mem_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- payments
-- -----------------------------------------------------------
CREATE TABLE `payments` (
  `id`                  INT(11)        NOT NULL AUTO_INCREMENT,
  `user_id`             INT(11)        NOT NULL,
  `amount`              DECIMAL(10,2)  NOT NULL,
  `method`              ENUM('paystack','offline','bank_transfer','cash','cheque','manual') NOT NULL,
  `status`              ENUM('pending','success','rejected','failed') NOT NULL DEFAULT 'pending',
  `reference`           VARCHAR(255)   DEFAULT NULL,
  `paystack_reference`  VARCHAR(255)   DEFAULT NULL,
  `receipt_file`        VARCHAR(500)   DEFAULT NULL,
  `notes`               TEXT           DEFAULT NULL,
  `approved_by`         INT(11)        DEFAULT NULL,
  `approved_at`         TIMESTAMP      NULL DEFAULT NULL,
  `created_at`          TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id`    (`user_id`),
  KEY `idx_approved_by` (`approved_by`),
  CONSTRAINT `fk_pay_user`     FOREIGN KEY (`user_id`)    REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pay_approver` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- Default Settings
-- -----------------------------------------------------------
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
  ('site_name',        'TUNEDIK Alumni Management System'),
  ('site_email',       'info@tunedik.org'),
  ('site_phone',       '+2348000000000'),
  ('site_address',     'Nigeria'),
  ('logo',             ''),
  ('favicon',          ''),
  ('facebook_url',     ''),
  ('twitter_url',      ''),
  ('instagram_url',    ''),
  ('linkedin_url',     ''),
  ('paystack_public_key',  ''),
  ('paystack_secret_key',  ''),
  ('bank_name',        ''),
  ('account_number',   ''),
  ('account_name',     ''),
  ('whatsapp_number',  ''),
  ('membership_fee',   '5000'),
  ('developer_url',    ''),
  ('_cleanup_last_run','0'),
  ('smtp_host',        'smtp.gmail.com'),
  ('smtp_port',        '587'),
  ('smtp_username',    ''),
  ('smtp_password',    ''),
  ('smtp_from_email',  'noreply@tunedik.org'),
  ('smtp_from_name',   'TUNEDIK Alumni'),
  ('smtp_encryption',  'tls');

-- -----------------------------------------------------------
-- donation_campaigns
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `donation_campaigns` (
  `id`                  INT(11)       NOT NULL AUTO_INCREMENT,
  `title`               VARCHAR(255)  NOT NULL,
  `description`         TEXT          DEFAULT NULL,
  `target_amount`       DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `beneficiary_user_id` INT(11)       DEFAULT NULL,
  `beneficiary_name`    VARCHAR(255)  DEFAULT NULL,
  `slug`                VARCHAR(32)   NOT NULL,
  `deadline`            DATE          DEFAULT NULL,
  `show_donors`         TINYINT(1)    NOT NULL DEFAULT 1,
  `status`              ENUM('active','closed','draft') NOT NULL DEFAULT 'active',
  `created_by`          INT(11)       NOT NULL,
  `created_at`          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_dc_beneficiary` FOREIGN KEY (`beneficiary_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_dc_creator`     FOREIGN KEY (`created_by`)          REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- donation_payments
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `donation_payments` (
  `id`           INT(11)       NOT NULL AUTO_INCREMENT,
  `campaign_id`  INT(11)       NOT NULL,
  `donor_name`   VARCHAR(255)  NOT NULL,
  `donor_email`  VARCHAR(255)  NOT NULL,
  `amount`       DECIMAL(10,2) NOT NULL,
  `reference`    VARCHAR(255)  NOT NULL,
  `method`       ENUM('paystack','manual') NOT NULL DEFAULT 'paystack',
  `status`       ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
  `message`      TEXT          DEFAULT NULL,
  `is_anonymous` TINYINT(1)    NOT NULL DEFAULT 0,
  `recorded_by`  INT(11)       DEFAULT NULL,
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ref` (`reference`),
  KEY `idx_campaign` (`campaign_id`),
  KEY `idx_status`   (`status`),
  CONSTRAINT `fk_dp_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `donation_campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dp_recorder` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- Default Admin User  (password: Admin@2024)
-- Run install.php to create with a proper bcrypt hash
-- -----------------------------------------------------------
-- The install.php script inserts the real hashed password.
-- This placeholder allows the DB to import cleanly.
