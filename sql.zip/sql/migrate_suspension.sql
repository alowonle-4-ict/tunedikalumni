-- TUNEDIK — Add suspension fields to users table
-- Run once. Plain ALTER (no IF NOT EXISTS for MySQL 5.x compatibility).

ALTER TABLE `users`
    ADD COLUMN `suspension_reason` VARCHAR(500) DEFAULT NULL AFTER `is_active`,
    ADD COLUMN `suspended_at`      TIMESTAMP    NULL        AFTER `suspension_reason`,
    ADD COLUMN `suspended_by`      INT(11)      DEFAULT NULL AFTER `suspended_at`;
