-- ============================================================
-- TUNEDIK — ID Card & Job Role Migration
-- Run after all prior migrations
-- ============================================================

-- Add current job role to users table
ALTER TABLE `users` ADD COLUMN `current_job_role` VARCHAR(255) DEFAULT NULL;
