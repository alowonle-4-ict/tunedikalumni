-- ============================================================
-- TUNEDIK — Election Management System Migration
-- ============================================================

-- 1. Add nec_member role to users
ALTER TABLE `users`
  MODIFY COLUMN `role`
    ENUM('member','financial_secretary','admin','nec_member')
    NOT NULL DEFAULT 'member';

-- 2. Election positions
CREATE TABLE IF NOT EXISTS `election_positions` (
  `id`                   INT(11)      NOT NULL AUTO_INCREMENT,
  `title`                VARCHAR(255) NOT NULL,
  `description`          TEXT         DEFAULT NULL,
  `application_start`    DATETIME     NOT NULL,
  `application_end`      DATETIME     NOT NULL,
  `voting_start`         DATETIME     NOT NULL,
  `voting_end`           DATETIME     NOT NULL,
  `candidates_published` TINYINT(1)   NOT NULL DEFAULT 0,
  `winner_notified`      TINYINT(1)   NOT NULL DEFAULT 0,
  `created_by`           INT(11)      NOT NULL,
  `created_at`           TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`           TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dates` (`voting_start`, `voting_end`),
  CONSTRAINT `fk_epos_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Applications (candidacy)
CREATE TABLE IF NOT EXISTS `election_applications` (
  `id`              INT(11)                               NOT NULL AUTO_INCREMENT,
  `user_id`         INT(11)                               NOT NULL,
  `position_id`     INT(11)                               NOT NULL,
  `manifesto`       TEXT                                  DEFAULT NULL,
  `status`          ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewer_notes`  TEXT                                  DEFAULT NULL,
  `reviewed_by`     INT(11)                               DEFAULT NULL,
  `reviewed_at`     TIMESTAMP                             NULL DEFAULT NULL,
  `created_at`      TIMESTAMP                             NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP                             NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_position` (`user_id`, `position_id`),
  KEY `idx_position` (`position_id`),
  KEY `idx_status`   (`status`),
  CONSTRAINT `fk_eapp_user`     FOREIGN KEY (`user_id`)     REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eapp_position` FOREIGN KEY (`position_id`) REFERENCES `election_positions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eapp_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Votes
CREATE TABLE IF NOT EXISTS `election_votes` (
  `id`             INT(11)   NOT NULL AUTO_INCREMENT,
  `voter_id`       INT(11)   NOT NULL,
  `position_id`    INT(11)   NOT NULL,
  `application_id` INT(11)   NOT NULL,
  `created_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_voter_position` (`voter_id`, `position_id`),
  KEY `idx_application` (`application_id`),
  CONSTRAINT `fk_ev_voter`       FOREIGN KEY (`voter_id`)       REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ev_position`    FOREIGN KEY (`position_id`)    REFERENCES `election_positions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ev_application` FOREIGN KEY (`application_id`) REFERENCES `election_applications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

