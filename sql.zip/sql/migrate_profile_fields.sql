-- ============================================================
-- TUNEDIK — Add profile_picture and matric_number to users
-- ============================================================

ALTER TABLE `users`
  ADD COLUMN `matric_number`   VARCHAR(50)  DEFAULT NULL AFTER `graduation_year`,
  ADD COLUMN `profile_picture` VARCHAR(255) DEFAULT NULL AFTER `matric_number`;
