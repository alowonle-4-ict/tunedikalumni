-- ============================================================
-- TUNEDIK — Member Signature Column
-- Run in MySQL Workbench: USE tunexapa_tunedik; then run this file
-- ============================================================

ALTER TABLE `users` ADD COLUMN `signature_file` VARCHAR(255) DEFAULT NULL;
