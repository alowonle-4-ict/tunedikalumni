-- ============================================================
-- TUNEDIK — Committee Management System Migration
-- ============================================================

CREATE TABLE IF NOT EXISTS `committees` (
  `id`          INT(11)                              NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(255)                         NOT NULL,
  `purpose`     TEXT                                 DEFAULT NULL,
  `start_date`  DATE                                 NOT NULL,
  `end_date`    DATE                                 DEFAULT NULL,
  `status`      ENUM('active','completed','dissolved') NOT NULL DEFAULT 'active',
  `created_by`  INT(11)                              NOT NULL,
  `created_at`  TIMESTAMP                            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP                            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_comm_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `committee_members` (
  `id`            INT(11)                   NOT NULL AUTO_INCREMENT,
  `committee_id`  INT(11)                   NOT NULL,
  `user_id`       INT(11)                   NOT NULL,
  `role`          ENUM('chair','member')     NOT NULL DEFAULT 'member',
  `joined_at`     DATE                       NOT NULL,
  `created_at`    TIMESTAMP                 NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_committee_user` (`committee_id`, `user_id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `fk_cm_committee` FOREIGN KEY (`committee_id`) REFERENCES `committees` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cm_user`      FOREIGN KEY (`user_id`)      REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
